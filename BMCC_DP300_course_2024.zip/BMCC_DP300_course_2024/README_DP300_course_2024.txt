README_DP300_course_2024.txt
11-15-2023
kbyron@bmcc.cuny.edu

Contents of BMCC_DP300_course_2024.zip:

This file:
  README_DP300_course_2024.txt

12 Powerpoint slide decks:
  dp300-s24-sess01.pptx
  dp300-s24-sess02.pptx
  dp300-s24-sess03.pptx
  dp300-s24-sess04.pptx
  dp300-s24-sess05.pptx
  dp300-s24-sess06.pptx
  dp300-s24-sess07.pptx
  dp300-s24-sess08.pptx
  dp300-s24-sess09.pptx
  dp300-s24-sess10.pptx
  dp300-s24-sess11.pptx
  dp300-s24-sess12.pptx

Course syllabus
  DP300_Syllabus_Fall2024.docx
  DP300_Syllabus_Fall2024.pdf

Lab assignments
  dp300-Lab_01-provision-sql-vm.pdf
  dp300-Lab_02-provision-sql-database.pdf
  dp300-Lab_03-authorize-access-azure-sql-database.pdf
  dp300-Lab_04-configure-firewall-rule.pdf
  dp300-Lab_05-enable-sql-defender-and-data-classification.pdf
  dp300-Lab_06-isolate-performance-problems.pdf
  dp300-Lab_07-detect-correct-fragmentation-issues.pdf
  dp300-Lab_08-identify-resolve-blocking-issues.pdf
  dp300-Lab_09-identify-issues-database-design.pdf
  dp300-Lab_10-isolate-problem-areas-poor-performing-queries.pdf
  dp300-Lab_11-deploy-azure-database-using-template.pdf
  dp300-Lab_12-create-cpu-status-alert.pdf
  dp300-Lab_13-deploy-automation-runbook-rebuild-indexes.pdf
  dp300-Lab_14-configure-geo-replication-for-azure-sql-database.pdf
  dp300-Lab_15-backup-url.pdf

